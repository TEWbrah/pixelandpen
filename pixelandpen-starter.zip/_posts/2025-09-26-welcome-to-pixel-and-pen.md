
---
layout: post
title: "Welcome to Pixel & Pen"
date: 2025-09-26
---

This is your first post. Edit or delete it, then add more stories by creating new files in **`_posts/`** named like:

```
YYYY-MM-DD-your-title.md
```

Write in **Markdown** — it’s just plain text with simple formatting.
