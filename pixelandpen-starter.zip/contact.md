
---
layout: default
title: Contact
permalink: /contact/
---

Email: you@example.com

You can also add a simple contact form from a service like Formspree or Basin.
